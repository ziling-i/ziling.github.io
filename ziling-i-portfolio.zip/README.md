# Ziling Chen — Portfolio

Personal portfolio for **Ziling Chen**, Junior Business Analyst | IT & Technology.

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a repository named `ziling-i.github.io`.
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder.
3. Add your resume as `assets/resume.pdf`.
4. In GitHub, open **Settings → Pages**.
5. Set the source to **Deploy from a branch**, select `main` and `/ (root)`, then save.
6. Your site will be available at `https://ziling-i.github.io/`.

## Before publishing
- Replace `YOUR_EMAIL@example.com` with your email.
- Replace the LinkedIn `#` links with your real LinkedIn URL.
- Add your final resume to `assets/resume.pdf`.
- Review all work-project wording and remove any confidential information.
